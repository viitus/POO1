public interface Financiavel {
    double calcularParcela(int meses);
    String exibirCondicoesFinanciamento();
}