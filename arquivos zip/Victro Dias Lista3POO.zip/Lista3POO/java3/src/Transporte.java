public interface Transporte {
    void iniciar();
    void parar();
    double calcularCusto(double distancia);
}
