public interface Compartilhavel {
    int calcularLugaresDisponiveis();
}
